const STORAGE = {
  tasks: 'agroway.field.demo.tasks.v1',
  queue: 'agroway.field.demo.queue.v1',
  activities: 'agroway.field.demo.activities.v1',
  planActions: 'agroway.field.demo.cycle.plan-actions.v1'
};

const baseTasks = [
  { id: 't1', title: 'Verificar humedad en sector N-3', detail: 'Medición manual de contraste · Lote Cacao Norte', time: '08:30', done: true },
  { id: 't2', title: 'Aplicar riego sectorizado', detail: 'Según verificación en campo · registrar volumen', time: '10:00', done: false },
  { id: 't3', title: 'Monitoreo de plagas', detail: 'Revisar 8 trampas cromáticas · evidencia fotográfica', time: '14:00', done: false },
  { id: 't4', title: 'Revisión de inventario', detail: 'Confirmar saldo Wondergreen Líquido', time: '16:30', done: false }
];

const baseActivities = [
  { id: 'a1', time: '08:42', occurredAt: '2026--8-11T08:42:00-05:00', title: 'Verificación manual registrada', detail: 'Humedad observada baja en sector N-3', source: 'Operario · local' },
  { id: 'a2', time: '07:55', occurredAt: '2026--8-11T07:55:00-05:00', title: 'Lectura de sensor normalizada', detail: 'Humedad 18% · temperatura 28.4 °C · pH 6.2', source: 'DEMO-N3' },
  { id: 'a3', time: 'Ayer', occurredAt: '2026--8-10T15:30:00-05:00', title: 'Riego completado', detail: 'Sector N-2 · 1,240 L · evidencia asociada', source: 'Operario' }
];

const baseCycleHistory = [
  { id: 'h1', occurredAt: '2026--8-09T10:20:00-05:00', label: '9 ago', title: 'Visita agronómica registrada', detail: 'Revisión de vigor, cobertura y condición fitosanitaria del lote.', source: 'Visita técnica' },
  { id: 'h2', occurredAt: '2026--8-03T09:05:00-05:00', label: '3 ago', title: 'Nutrición de mantenimiento aplicada', detail: 'Aplicación registrada contra plan; lote, insumo y evidencia vinculados.', source: 'Field Operations' },
  { id: 'h3', occurredAt: '2026--7-28T13:10:00-05:00', label: '28 jul', title: 'Plan agronómico actualizado', detail: 'Se confirmó continuidad de la etapa vegetativa y ventana de poda de formación.', source: 'Plan Greenatics' },
  { id: 'h4', occurredAt: '2026--2-18T07:30:00-05:00', label: '18 feb', title: 'Ciclo 2026--1 iniciado', detail: 'Establecimiento del lote asociado a Finca El Porvenir · Cacao Norte.', source: 'Land / Crop Cycle' }
];

const safeParse = (key, fallback) => {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
};

const state = {
  tasks: safeParse(STORAGE.tasks, baseTasks),
  queue: safeParse(STORAGE.queue, []),
  activities: safeParse(STORAGE.activities, baseActivities),
  planActions: safeParse(STORAGE.planActions, {}),
  currentView: 'home',
  cycleTab: 'summary',
  pendingPlanAction: null
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function persist() {
  localStorage.setItem(STORAGE.tasks, JSON.stringify(state.tasks));
  localStorage.setItem(STORAGE.queue, JSON.stringify(state.queue));
  localStorage.setItem(STORAGE.activities, JSON.stringify(state.activities));
  localStorage.setItem(STORAGE.planActions, JSON.stringify(state.planActions));
}

function renderTasks() {
  const list = $('#taskList');
  if (!list) return;
  list.innerHTML = state.tasks.map(task => `
    <article class="task-row ${task.done ? 'is-done' : ''}">
      <button class="task-check" data-task="${task.id}" aria-label="${task.done ? 'Reabrir' : 'Completar'}: ${task.title}" aria-pressed="${task.done}">${task.done ? '✓' : ''}</button>
      <div class="task-copy"><strong>${task.title}</strong><small>${task.detail}</small></div>
      <time class="task-time">${task.time}</time>
    </article>`).join('');
  const done = state.tasks.filter(t => t.done).length;
  $('#taskProgress').textContent = `${done} de ${state.tasks.length} completadas`;
  $$('[data-task]').forEach(button => button.addEventListener('click', () => toggleTask(button.dataset.task)));
}

function toggleTask(id) {
  const task = state.tasks.find(t => t.id === id);
  if (!task) return;
  task.done = !task.done;
  const now = new Date();
  const event = {
    id: crypto.randomUUID(),
    kind: task.done ? 'TASK_COMPLETED' : 'TASK_REOPENED',
    title: task.title,
    createdAt: now.toISOString()
  };
  state.queue.unshift(event);
  state.activities.unshift({
    id: event.id,
    time: new Intl.DateTimeFormat('es-CO', { hour: '2-digit', minute: '2-digit' }).format(now),
    occurredAt: now.toISOString(),
    title: task.done ? 'Tarea completada' : 'Tarea reabierta',
    detail: task.title,
    source: 'Dispositivo · pendiente'
  });
  persist(); renderTasks(); renderActivities(); renderCycleHistory(); renderSyncState();
  toast(task.done ? 'Tarea guardada en el dispositivo' : 'Cambio guardado en el dispositivo');
}

function renderActivities() {
  const feed = $('#activityFeed');
  if (!feed) return;
  feed.innerHTML = state.activities.slice(0, 6).map(a => `
    <article class="activity-entry">
      <time>${a.time}</time>
      <div class="activity-copy"><strong>${a.title}</strong><small>${a.detail}</small></div>
      <span class="activity-source">${a.source}</span>
    </article>`).join('');
}

function renderCycleHistory() {
  const list = $('#cycleHistory');
  if (!list) return;
  const local = state.activities.map(a => ({
    id: `cycle-${a.id}`,
    occurredAt: a.occurredAt || new Date().toISOString(),
    label: a.time,
    title: a.title,
    detail: a.detail,
    source: a.source
  }));
  const entries = [...local, ...baseCycleHistory]
    .sort((a,b) => Date.parse(b.occurredAt) - Date.parse(a.occurredAt))
    .slice(0, 12);
  list.innerHTML = entries.map(entry => `
    <article class="cycle-history-entry">
      <time datetime="${entry.occurredAt}">${entry.label}</time>
      <span class="history-node" aria-hidden="true"></span>
      <div class="cycle-history-copy"><strong>${entry.title}</strong><small>${entry.detail}</small></div>
      <span class="history-source">${entry.source}</span>
    </article>`).join('');
}

function renderPlanActions() {
  $$('[data-plan-id]').forEach(article => {
    const done = Boolean(state.planActions[article.dataset.planId]);
    article.classList.toggle('is-recorded', done);
    const chip = $('.plan-state', article);
    const button = $('.plan-record', article);
    if (done) {
      if (chip) chip.textContent = 'Registrado local';
      if (button) { button.textContent = 'Registrar nueva evidencia'; button.dataset.recorded = 'true'; }
    }
  });
}

function renderQueue() {
  const list = $('#queueList');
  if (!list) return;
  if (!state.queue.length) {
    list.innerHTML = '<div class="queue-empty">No hay cambios locales pendientes.</div>';
    return;
  }
  list.innerHTML = state.queue.map(item => `
    <article class="queue-item"><strong>${item.kind.replaceAll('_', ' ')}</strong><span>${item.title}</span><small>${new Date(item.createdAt).toLocaleString('es-CO')}</small></article>`).join('');
}

function renderSyncState() {
  const online = navigator.onLine;
  const pending = state.queue.length;
  $('#syncDot').classList.toggle('offline', !online || pending > 0);
  $('#syncLabel').textContent = online ? (pending ? 'Local pendiente' : 'En línea') : 'Sin conexión';
  $('#syncDetail').textContent = pending ? `${pending} cambio${pending === 1 ? '' : 's'} en dispositivo` : 'Sin cambios pendientes';
}

function toast(message) {
  const region = $('#toastRegion');
  const node = document.createElement('div');
  node.className = 'toast'; node.textContent = message; region.appendChild(node);
  setTimeout(() => node.remove(), 2800);
}

function openDialog(id) {
  const dialog = document.getElementById(id);
  if (dialog?.showModal) dialog.showModal();
}

function setView(view, { focus = false } = {}) {
  if (!['home','lotes'].includes(view)) {
    toast(`${view[0].toUpperCase()}${view.slice(1)} está definido en arquitectura y se materializará en una siguiente vertical.`);
    return;
  }
  state.currentView = view;
  $('#homeView').hidden = view !== 'home';
  $('#lotView').hidden = view !== 'lotes';
  $$('[data-view]').forEach(button => {
    const active = button.dataset.view === view;
    button.classList.toggle('is-active', active);
    if (active) button.setAttribute('aria-current','page'); else button.removeAttribute('aria-current');
  });
  document.title = view === 'lotes' ? 'Cacao Norte · AGROWAY FIELD' : 'AGROWAY FIELD';
  if (view === 'lotes') { renderCycleHistory(); renderPlanActions(); }
  if (focus) $('#contenido').focus({ preventScroll: true });
  window.scrollTo({ top: 0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
}

function setCycleTab(tab, { focus = false } = {}) {
  const valid = ['summary','plan','monitoring','history'];
  if (!valid.includes(tab)) return;
  state.cycleTab = tab;
  $$('[data-cycle-tab]').forEach(button => {
    const active = button.dataset.cycleTab === tab;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-selected', String(active));
    button.tabIndex = active ? 0 : -1;
  });
  $$('[data-cycle-panel]').forEach(panel => { panel.hidden = panel.dataset.cyclePanel !== tab; });
  if (tab === 'history') renderCycleHistory();
  if (focus) $(`[data-cycle-tab="${tab}"]`)?.focus();
}

function prepareActivity({ type = 'Observación', notes = '', planAction = null } = {}) {
  state.pendingPlanAction = planAction;
  $('#activityType').value = type;
  $('#activityNotes').value = notes;
  openDialog('activityDialog');
  queueMicrotask(() => $('#activityNotes').focus());
}

$('#activityButton').addEventListener('click', () => prepareActivity());
$('#mobileActivityButton').addEventListener('click', () => prepareActivity());
$('#cycleObservationButton').addEventListener('click', () => prepareActivity({ type: 'Observación' }));
$('#queueButton').addEventListener('click', () => { renderQueue(); openDialog('queueDialog'); });
$('#contextButton').addEventListener('click', () => openDialog('contextDialog'));
$('#copilotButton').addEventListener('click', () => openDialog('evidenceDialog'));
$('#cycleCopilotButton').addEventListener('click', () => openDialog('evidenceDialog'));
$('#passportButton').addEventListener('click', () => openDialog('passportDialog'));

$$('[data-close-dialog]').forEach(button => button.addEventListener('click', () => document.getElementById(button.dataset.closeDialog)?.close()));

$('#activityForm').addEventListener('submit', event => {
  if (event.submitter?.value === 'cancel') { state.pendingPlanAction = null; return; }
  event.preventDefault();
  const type = $('#activityType').value;
  const lot = $('#activityLot').value;
  const notes = $('#activityNotes').value.trim();
  if (!notes) return;
  const id = crypto.randomUUID();
  const now = new Date();
  const kind = state.pendingPlanAction ? 'CYCLE_PLAN_EVIDENCE_RECORDED' : 'FIELD_ACTIVITY_RECORDED';
  state.queue.unshift({ id, kind, title: `${type} · ${lot}`, notes, planAction: state.pendingPlanAction, createdAt: now.toISOString() });
  state.activities.unshift({
    id,
    time: new Intl.DateTimeFormat('es-CO', { hour: '2-digit', minute: '2-digit' }).format(now),
    occurredAt: now.toISOString(),
    title: state.pendingPlanAction ? `${type} · evidencia del plan` : `${type} registrado`,
    detail: `${lot} · ${notes}`,
    source: 'Dispositivo · pendiente'
  });
  if (state.pendingPlanAction) state.planActions[state.pendingPlanAction] = { recordedAt: now.toISOString(), activityId: id };
  state.pendingPlanAction = null;
  persist(); renderActivities(); renderCycleHistory(); renderPlanActions(); renderSyncState();
  $('#activityNotes').value = '';
  $('#activityDialog').close();
  toast(kind === 'CYCLE_PLAN_EVIDENCE_RECORDED' ? 'Evidencia del plan guardada localmente' : 'Actividad guardada localmente');
});

$$('[data-focus]').forEach(button => button.addEventListener('click', () => {
  const target = document.getElementById(button.dataset.focus);
  if (!target) return;
  target.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center' });
  target.classList.remove('flash-focus'); requestAnimationFrame(() => target.classList.add('flash-focus'));
}));

$$('[data-route]').forEach(button => button.addEventListener('click', () => setView(button.dataset.route, { focus: true })));
$$('[data-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.view)));
$$('[data-nav]').forEach(button => button.addEventListener('click', () => setView(button.dataset.nav)));

$$('[data-cycle-tab]').forEach(button => {
  button.addEventListener('click', () => setCycleTab(button.dataset.cycleTab));
  button.addEventListener('keydown', event => {
    if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
    event.preventDefault();
    const tabs = $$('[data-cycle-tab]');
    const current = tabs.indexOf(button);
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (current + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
    setCycleTab(tabs[next].dataset.cycleTab, { focus: true });
  });
});

$$('[data-cycle-tab-open]').forEach(button => button.addEventListener('click', () => {
  setView('lotes');
  setCycleTab(button.dataset.cycleTabOpen);
  requestAnimationFrame(() => $(`[data-cycle-tab="${button.dataset.cycleTabOpen}"]`)?.focus());
}));

$$('[data-plan-action]').forEach(button => button.addEventListener('click', () => {
  prepareActivity({
    type: button.dataset.activityType || 'Observación',
    notes: button.dataset.activityNotes || '',
    planAction: button.dataset.planAction
  });
}));

window.addEventListener('online', renderSyncState);
window.addEventListener('offline', renderSyncState);

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  navigator.serviceWorker.register('./service-worker.js').catch(() => {});
}

renderTasks();
renderActivities();
renderCycleHistory();
renderPlanActions();
renderSyncState();
setCycleTab('summary');
setView('home');
